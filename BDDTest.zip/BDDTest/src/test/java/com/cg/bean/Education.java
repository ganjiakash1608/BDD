package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Education {

	@FindBy(id = "graduation")
	private WebElement graduation;

	@FindBy(id = "percentage")
	private WebElement percentage;

	@FindBy(id = "passingYear")
	private WebElement year;

	@FindBy(id = "projectName")
	private WebElement projectName;

	@FindBy(id = "technologies")
	private WebElement technologies;

	@FindBy(id = "otherTechno")
	private WebElement otherTechno;

	@FindBy(id = "btnPayment")
	private WebElement makePayment;

	public void selectGraduation(int gradVal) {
		Select select = new Select(graduation);
		select.selectByIndex(gradVal);
	}

	public String getPercentage() {
		return percentage.getAttribute("value");
	}

	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);
	}

	public String getYear() {
		return year.getAttribute("value");
	}

	public void setYear(String year) {
		this.year.sendKeys(year);
	}

	public String getProjectName() {
		return projectName.getAttribute("value");
	}

	public void setProjectName(String projectName) {
		this.projectName.sendKeys(projectName);
		;
	}

	public void selectTechnologies(int tech) {
		Select select = new Select(technologies);
		select.selectByIndex(tech);
	}

	public String getOtherTechno() {
		return otherTechno.getAttribute("value");
	}

	public void setOtherTechno(String otherTechno) {
		this.otherTechno.sendKeys(otherTechno);
		;
	}

	public void clickMakePayment() {
		makePayment.click();
	}

}
