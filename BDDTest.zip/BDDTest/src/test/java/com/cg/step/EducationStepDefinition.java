package com.cg.step;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Education;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EducationStepDefinition {
	
	private WebDriver driver;
	private Education education;
	
	@Before
	public void init() {
		// Instantiate driver
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@After
	public void destroy() {
		driver.quit();
	}
	
	@Given("^user is on educational page$")
	public void user_is_on_educational_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String url = "file:///C:/Users/akganji/BDDWorkspace/BDDTest/html/EducationalDetails.html";
		driver.get(url);
		education = new Education();
		PageFactory.initElements(driver, education);
	}

	@Then("^educational validate title$")
	public void educational_validate_title() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.getTitle();
		String log="Educational Form";
		Assert.assertEquals(driver.getTitle(), log);
	}

	@When("^invalid graduation$")
	public void invalid_graduation() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		education.selectGraduation(0);
		education.setPercentage("71");
		education.setYear("2018");
		education.setProjectName("IOT");
		education.selectTechnologies(2);
		education.setOtherTechno("Any other");
	}

	@Then("^educational validation$")
	public void educational_validation() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		education.clickMakePayment();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^invalid percentage$")
	public void invalid_percentage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		education.selectGraduation(1);
		education.setPercentage("");
		education.setYear("2018");
		education.setProjectName("IOT");
		education.selectTechnologies(2);
		education.setOtherTechno("Any other");
	}

	@When("^invalid passing year$")
	public void invalid_passing_year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		education.selectGraduation(1);
		education.setPercentage("71");
		education.setYear("");
		education.setProjectName("IOT");
		education.selectTechnologies(2);
		education.setOtherTechno("Any other");
	}

	@When("^invalid project name$")
	public void invalid_project_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		education.selectGraduation(1);
		education.setPercentage("71");
		education.setYear("2018");
		education.setProjectName("");
		education.selectTechnologies(2);
		education.setOtherTechno("Any other");
	}

	@When("^invalid technologies$")
	public void invalid_technologies() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		education.selectGraduation(1);
		education.setPercentage("71");
		education.setYear("2018");
		education.setProjectName("IOT");
		education.selectTechnologies(0);
		education.setOtherTechno("Any other");
	}

	@When("^invalid other technology details$")
	public void invalid_other_technology_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actionseducation.selectGraduation(1);
		education.setPercentage("71");
		education.setYear("2018");
		education.setProjectName("IOT");
		education.selectTechnologies(2);
		education.setOtherTechno("");
	}

	@When("^perfect details$")
	public void perfect_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		education.selectGraduation(1);
		education.setPercentage("71");
		education.setYear("2018");
		education.setProjectName("IOT");
		education.selectTechnologies(2);
		education.setOtherTechno("Any other");
	}

	@Then("^click make payment$")
	public void click_make_payment() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		education.clickMakePayment();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

}
