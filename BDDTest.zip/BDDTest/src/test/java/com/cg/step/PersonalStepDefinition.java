package com.cg.step;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Personal;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalStepDefinition {
	
	private WebDriver driver;
	private Personal personal;
	
	@Before
	public void init() {
		// Instantiate driver
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@After
	public void destroy() {
		driver.quit();
	}
	
	@Given("^user is on login page$")
	public void user_is_on_login_page() throws Throwable {
		String url = "file:///C:/Users/akganji/BDDWorkspace/BDDTest/html/PersonalDetails.html";
		driver.get(url);
		personal = new Personal();
		PageFactory.initElements(driver, personal);
	}

	@Then("^validate title$")
	public void validate_title() throws Throwable {
		driver.getTitle();
		String log="Personal Details";
		Assert.assertEquals(driver.getTitle(), log);
	}

	@When("^invalid first name$")
	public void invalid_first_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personal.setFirstName("");
		personal.setLastName("Ganji");
		personal.setEmail("ganji@akash.com");
		personal.setPhoneNumber("9594447117");
		personal.setAddress1("Sector 20");
		personal.setAddress2("Belapur");
		personal.clickCity();
		personal.clickState();
	}

	@Then("^validate first name$")
	public void validate_first_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personal.clickNextButton();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^invalid last name$")
	public void invalid_last_name() throws Throwable {
		personal.setFirstName("Akash");
		personal.setLastName("");
		personal.setEmail("ganji@akash.com");
		personal.setPhoneNumber("9594447117");
		personal.setAddress1("Sector 20");
		personal.setAddress2("Belapur");
		personal.clickCity();
		personal.clickState();
	}

	@Then("^validate last name$")
	public void validate_last_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personal.clickNextButton();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^invalid email$")
	public void invalid_email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personal.setFirstName("Akash");
		personal.setLastName("Ganji");
		personal.setEmail("abc");
		personal.setPhoneNumber("9594447117");
		personal.setAddress1("Sector 20");
		personal.setAddress2("Belapur");
		personal.clickCity();
		personal.clickState();
	}

	@Then("^validate email$")
	public void validate_email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personal.clickNextButton();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^invalid contact$")
	public void invalid_contact() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personal.setFirstName("Akash");
		personal.setLastName("Ganji");
		personal.setEmail("ganji@akash.com");
		personal.setPhoneNumber("9594");
		personal.setAddress1("Sector 20");
		personal.setAddress2("Belapur");
		personal.clickCity();
		personal.clickState();
	}

	@Then("^validate contact$")
	public void validate_contact() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personal.clickNextButton();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		
	}

	@When("^invalid address one$")
	public void invalid_address_one() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personal.setFirstName("Akash");
		personal.setLastName("Ganji");
		personal.setEmail("ganji@akash.com");
		personal.setPhoneNumber("9594447117");
		personal.setAddress1("");
		personal.setAddress2("Belapur");
		personal.clickCity();
		personal.clickState();
	}

	@Then("^validate address one$")
	public void validate_address_one() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personal.clickNextButton();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^invalid address two$")
	public void invalid_address_two() throws Throwable {
		personal.setFirstName("Akash");
		personal.setLastName("Ganji");
		personal.setEmail("ganji@akash.com");
		personal.setPhoneNumber("9594447117");
		personal.setAddress1("Sector 20");
		personal.setAddress2("");
		personal.clickCity();
		personal.clickState();
	}

	@Then("^validate address two$")
	public void validate_address_two() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personal.clickNextButton();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}
	
	
	@When("^invalid city$")
	public void invalid_city() throws Throwable {
		personal.setFirstName("Akash");
		personal.setLastName("Ganji");
		personal.setEmail("ganji@akash.com");
		personal.setPhoneNumber("9594447117");
		personal.setAddress1("Sector 20");
		personal.setAddress2("Belapur");
		personal.clickState();
		
	}

	@Then("^validate city$")
	public void validate_city() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personal.clickNextButton();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^invalid state$")
	public void invalid_state() throws Throwable {
		personal.setFirstName("Akash");
		personal.setLastName("Ganji");
		personal.setEmail("ganji@akash.com");
		personal.setPhoneNumber("9594447117");
		personal.setAddress1("Sector 20");
		personal.setAddress2("Belapur");
		personal.clickCity();
	}

	@Then("^validate state$")
	public void validate_state() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personal.clickNextButton();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^correct entries$")
	public void correct_entries() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personal.setFirstName("Akash");
		personal.setLastName("Ganji");
		personal.setEmail("ganji@akash.com");
		personal.setPhoneNumber("9594447117");
		personal.setAddress1("Sector 20");
		personal.setAddress2("Belapur");
		personal.clickCity();
		personal.clickState();
	}

	@Then("^switch to next page$")
	public void switch_to_next_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personal.clickNextButton();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

}
