package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Education {

	@FindBy(id = "graduation")
	WebElement graduation;

	@FindBy(id = "percent")
	WebElement percent;

	@FindBy(id = "year")
	WebElement year;

	@FindBy(id = "project")
	WebElement project;

	@FindBy(id = "technology")
	WebElement technology;

	@FindBy(id = "other")
	WebElement other;

	@FindBy(id = "make_payment")
	WebElement make_payment;

	public String getOther() {
		return this.other.getAttribute("value");
	}

	public void setOther(String other) {
		this.other.sendKeys(other);
	}

	public String getPercent() {
		return this.percent.getAttribute("value");
	}

	public void setPercent(String percent) {
		this.percent.sendKeys(percent);
	}

	public String getYear() {
		return this.year.getAttribute("value");
	}

	public void setYear(String year) {
		this.year.sendKeys(year);
	}

	public String getProject() {
		return this.project.getAttribute("value");
	}

	public void setProject(String project) {
		this.project.sendKeys(project);
	}

	public void clickGraduation(int idx) {
		Select select = new Select(graduation);
		select.selectByIndex(idx);
	}

	public void clickTechnology(int idx1) {
		Select select = new Select(technology);
		select.selectByIndex(idx1);
	}

	public void make_payment() {
		make_payment.click();
	}
}
