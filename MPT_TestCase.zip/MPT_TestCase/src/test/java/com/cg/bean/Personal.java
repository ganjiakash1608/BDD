package com.cg.bean;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.WebElement;

public class Personal {

	@FindBy(id = "firstname")
	WebElement firstname;

	@FindBy(id = "lastname")
	WebElement lastname;

	@FindBy(id = "email")
	WebElement email;

	@FindBy(id = "number")
	WebElement number;

	@FindBy(id = "address1")
	WebElement address1;

	@FindBy(id = "address2")
	WebElement address2;

	@FindBy(id = "city")
	WebElement city;

	@FindBy(id = "state")
	WebElement state;

	@FindBy(id = "next")
	WebElement next;

	public String getFirstname() {
		return this.firstname.getAttribute("value");
	}

	public void setFirstname(String firstname) {
		this.firstname.sendKeys(firstname);
	}

	public String getLastname() {
		return this.lastname.getAttribute("value");
	}

	public void setLastname(String lastname) {
		this.lastname.sendKeys(lastname);
	}

	public String getEmail() {
		return this.email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getNumber() {
		return this.number.getAttribute("value");
	}

	public void setNumber(String number) {
		this.number.sendKeys(number);
	}

	public String getAddress1() {
		return this.address1.getAttribute("value");
	}

	public void setAddress1(String address1) {
		this.address1.sendKeys(address1);
	}

	public String getAddress2() {
		return this.address2.getAttribute("value");
	}

	public void setAddress2(String address2) {
		this.address2.sendKeys(address2);
	}

	public void clickCity(int idx) {
		Select select = new Select(city);
		select.selectByIndex(idx);
	}

	public void clickState(int idx1) {
		Select select = new Select(state);
		select.selectByIndex(idx1);
	}

	public void next() {
		next.click();
	}
}
