package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Education;
import com.cg.bean.Personal;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalStepDefination {

	private WebDriver driver;

	private Personal personal;
 
	private Education education;
	
	

	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\adhodi\\Desktop\\Selenium\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}

	@After
	public void destroy() {
		driver.quit();
	}

	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Throwable {
		String url = "C:\\Users\\adhodi\\STSWork\\MPT_TestCase\\html\\PersonalDetails.html";
		driver.get(url);
		Thread.sleep(1000);
		personal = new Personal();
		PageFactory.initElements(driver, personal);
		System.out.println("Registration page is opened");

	}

	@Then("^Validate login page$")
	public void validate_login_page() throws Throwable {
		String title = "Personal Detail";
		if(driver.getTitle().equals(title)) {
			System.out.println("Correct page");
		}
		
	}

	@When("^User enters firstname$")
	public void user_enters_firstname() throws Throwable {
		personal.setFirstname("");
		personal.setLastname("Dhodi");
		personal.setEmail("ank@gmail.com");
		personal.setNumber("8369471866");
		personal.setAddress1("Borivali");
		personal.setAddress2("Gorai");
		personal.clickCity(1);
		personal.clickState(1);
		Thread.sleep(3000);

	}

	@Then("^Validate firstname$")
	public void validate_firstname() throws Throwable {
		personal.next();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);

	}

	@When("^User enters lastname$")
	public void user_enters_lastname() throws Throwable {
		personal.setFirstname("Ankush");
		personal.setLastname("");
		personal.setEmail("ank@gmail.com");
		personal.setNumber("8369471866");
		personal.setAddress1("Borivali");
		personal.setAddress2("Gorai");
		personal.clickCity(1);
		personal.clickState(1);
		Thread.sleep(3000);

	}

	@Then("^Validate lastname$")
	public void validate_lastname() throws Throwable {
		personal.next();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);

	}

	@When("^User enters email$")
	public void user_enters_email() throws Throwable {
		personal.setFirstname("Ankush");
		personal.setLastname("Dhodi");
		personal.setEmail("ankush");
		personal.setNumber("8369471866");
		personal.setAddress1("Borivali");
		personal.setAddress2("Gorai");
		personal.clickCity(1);
		personal.clickState(1);
		Thread.sleep(3000);

	}

	@Then("^Validate email$")
	public void validate_email() throws Throwable {
		personal.next();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);

	}

	@When("^User enters contactnumber$")
	public void user_enters_contactnumber() throws Throwable {
		personal.setFirstname("Ankush");
		personal.setLastname("Dhodi");
		personal.setEmail("ankush@gmail.com");
		personal.setNumber("12345");
		personal.setAddress1("Borivali");
		personal.setAddress2("Gorai");
		personal.clickCity(1);
		personal.clickState(1);
		Thread.sleep(3000);
	}

	@Then("^Validate contactnumber$")
	public void validate_contactnumber() throws Throwable {
		personal.next();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User enters addlineone$")
	public void user_enters_addlineone() throws Throwable {
		personal.setFirstname("Ankush");
		personal.setLastname("Dhodi");
		personal.setEmail("ankush@gmail.com");
		personal.setNumber("8369471866");
		personal.setAddress1("");
		personal.setAddress2("Gorai");
		personal.clickCity(1);
		personal.clickState(1);
		Thread.sleep(3000);

	}

	@Then("^Validate addlineone$")
	public void validate_addlineone() throws Throwable {
		personal.next();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User enters addlinetwo$")
	public void user_enters_addlinetwo() throws Throwable {
		personal.setFirstname("Ankush");
		personal.setLastname("Dhodi");
		personal.setEmail("ankush");
		personal.setNumber("8369471866");
		personal.setAddress1("Borivali");
		personal.setAddress2("");
		personal.clickCity(1);
		personal.clickState(1);
		Thread.sleep(3000);
	}

	@Then("^Validate addlinetwo$")
	public void validate_addlinetwo() throws Throwable {
		personal.next();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User select city$")
	public void user_select_city() throws Throwable {
		personal.setFirstname("Ankush");
		personal.setLastname("Dhodi");
		personal.setEmail("ankush@gmail.com");
		personal.setNumber("8369471866");
		personal.setAddress1("Borivali");
		personal.setAddress2("Gorai");
		personal.clickCity(0);
		personal.clickState(1);
		Thread.sleep(3000);

	}

	@Then("^Validate city$")
	public void validate_city() throws Throwable {
		personal.next();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User select state$")
	public void user_select_state() throws Throwable {
		personal.setFirstname("Ankush");
		personal.setLastname("Dhodi");
		personal.setEmail("ankush@gmail.com");
		personal.setNumber("8369471866");
		personal.setAddress1("Borivali");
		personal.setAddress2("Gorai");
		personal.clickCity(1);
		personal.clickState(0);
		Thread.sleep(3000);
	}

	@Then("^Validate state$")
	public void validate_state() throws Throwable {
		personal.next();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User submit form$")
	public void user_submit_form() throws Throwable {
		personal.setFirstname("Ankush");
		personal.setLastname("Dhodi");
		personal.setEmail("ankush@gmail.com");
		personal.setNumber("8369471866");
		personal.setAddress1("Borivali");
		personal.setAddress2("Gorai");
		personal.clickCity(1);
		personal.clickState(1);
		Thread.sleep(3000);
	}

	@Then("^Show success alert$")
	public void show_success_alert() throws Throwable {
		personal.next();
		driver.switchTo().alert().accept();
	}

	@Given("^User is on education page$")
	public void user_is_on_education_page() throws Throwable {
		String url = "C:\\Users\\adhodi\\STSWork\\MPT_TestCase\\html\\EducationalDetails.html";
		driver.get(url);
		Thread.sleep(1000);
		education = new Education();
		PageFactory.initElements(driver, education);
		System.out.println("Education page is opened");
	}

	@Then("^Validate education page$")
	public void validate_education_page() throws Throwable {
		String title = "Education Detail";
		System.out.println("User is on correct page");
		if (!driver.getTitle().equals(title)) {
			System.exit(0);
		}
	}

	@When("^User select graduation$")
	public void user_select_graduation() throws Throwable {
		education.clickGraduation(0);
		education.setPercent("60");
		education.setYear("2018");
		education.setProject("ABC");
		education.clickTechnology(1);
		Thread.sleep(3000);
	}

	@Then("^Validate graduation$")
	public void validate_graduation() throws Throwable {
		education.make_payment();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User enters percent$")
	public void user_enters_percent() throws Throwable {
		education.clickGraduation(1);
		education.setPercent("6");
		education.setYear("2018");
		education.setProject("ABC");
		education.clickTechnology(1);
		Thread.sleep(3000);

	}

	@Then("^Validate percent$")
	public void validate_percent() throws Throwable {
		education.make_payment();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User enters passing year$")
	public void user_enters_passing_year() throws Throwable {
		education.clickGraduation(1);
		education.setPercent("60");
		education.setYear("201");
		education.setProject("ABC");
		education.clickTechnology(1);
		Thread.sleep(3000);
	}

	@Then("^Validate passing year$")
	public void validate_passing_year() throws Throwable {
		education.make_payment();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User enters project name$")
	public void user_enters_project_name() throws Throwable {
		education.clickGraduation(1);
		education.setPercent("60");
		education.setYear("2018");
		education.setProject("");
		education.clickTechnology(1);
		Thread.sleep(3000);
	}

	@Then("^Validate project name$")
	public void validate_project_name() throws Throwable {
		education.make_payment();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User enters technology$")
	public void user_enters_technology() throws Throwable {
		education.clickGraduation(1);
		education.setPercent("60");
		education.setYear("2018");
		education.setProject("ABC");
		education.clickTechnology(0);
		Thread.sleep(3000);
	}

	@Then("^Validate technology$")
	public void validate_technology() throws Throwable {
		education.make_payment();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User enters other technology$")
	public void user_enters_other_technology() throws Throwable {
		education.clickGraduation(1);
		education.setPercent("60");
		education.setYear("2018");
		education.setProject("ABC");
		education.clickTechnology(4);
		education.setOther("");
		Thread.sleep(3000);
	}

	@Then("^Validate other technology$")
	public void validate_other_technology() throws Throwable {
		education.make_payment();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User make payment$")
	public void user_make_payment() throws Throwable {
		education.clickGraduation(1);
		education.setPercent("60");
		education.setYear("2018");
		education.setProject("ABC");
		education.clickTechnology(4);
		education.setOther("PYTHON");
		Thread.sleep(3000);
	}

	@Then("^Show registration success alert$")
	public void show_registration_success_alert() throws Throwable {
		education.make_payment();
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
	}
	

}
